Commited .git directories, wtf?!
--------------------------------
Those are used during **integration tests** - now it doesn't sound silly but rather awesome, right? ;-)
